// JavaScript code to handle tab switching and image uploading

function openTab(tabName) {
    var i, tabContent;
    tabContent = document.getElementsByClassName("tab-content");
    for (i = 0; i < tabContent.length; i++) {
        tabContent[i].style.display = "none";
    }
    document.getElementById(tabName).style.display = "block";
}

function uploadImages() {
    var input = document.getElementById("image-upload");
    var slider = document.getElementById("image-slider");
    slider.innerHTML = ""; // Clear previous images

    for (var i = 0; i < input.files.length; i++) {
        var file = input.files[i];
        var image = document.createElement("img");
        image.src = URL.createObjectURL(file);
        image.className = "slider-image";
        slider.appendChild(image);
    }

    // Display the image slider tab after uploading
    openTab("slider-tab");
}
